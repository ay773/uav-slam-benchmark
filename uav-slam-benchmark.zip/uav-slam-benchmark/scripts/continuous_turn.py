import airsim
import time

client = airsim.MultirotorClient()
client.confirmConnection()
client.enableApiControl(True)
client.armDisarm(True)

print("Taking off...")
client.takeoffAsync().join()
time.sleep(2)

print("Flying forward while turning>>>>")
duration = 10  # seconds
start_time = time.time()

while time.time() - start_time < duration:
    # Forward + Yaw rotation (turning)
    client.moveByVelocityAsync(1, 0, 0, 1, yaw_mode=airsim.YawMode(is_rate=True, yaw_or_rate=10))
    time.sleep(0.1)

print("Hovering>>>>")
client.moveByVelocityAsync(0, 0, 0, 1).join()
