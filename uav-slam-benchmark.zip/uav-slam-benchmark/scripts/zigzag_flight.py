import airsim
import time
import math

# Connect to AirSim
drone = airsim.MultirotorClient()
drone.confirmConnection()
drone.enableApiControl(True)
drone.armDisarm(True)

print("Taking off...")
drone.takeoffAsync().join()
drone.moveByVelocityAsync(0, 0, 0, 2).join()  # Hover a bit

print("Flying forward...")
drone.moveByVelocityAsync(3, 0, 0, 2).join()

print("Turning left (yaw -30 deg)...")
drone.rotateByYawRateAsync(-30, 1).join()

print("Flying forward...")
drone.moveByVelocityAsync(3, 0, 0, 2).join()

print("Turning right (yaw +60 deg)...")
drone.rotateByYawRateAsync(60, 1).join()

print("Flying forward...")
drone.moveByVelocityAsync(3, 0, 0, 2).join()

print("Returning to hover...")
drone.rotateByYawRateAsync(-30, 1).join()  # Back to original heading
drone.hoverAsync().join()

print("Landing...")
drone.landAsync().join()
drone.armDisarm(False)
drone.enableApiControl(False)

print("><><><Zigzag flight completed><><><.")
