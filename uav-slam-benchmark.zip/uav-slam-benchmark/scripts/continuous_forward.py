import airsim
import time

client = airsim.MultirotorClient()
client.confirmConnection()
client.enableApiControl(True)
client.armDisarm(True)

# Take off
client.takeoffAsync().join()
print("Drone is airborne and moving forward>>>")

# Move forward continuously
while True:
    client.moveByVelocityAsync(1, 0, 0, duration=1,
        drivetrain=airsim.DrivetrainType.ForwardOnly,
        yaw_mode=airsim.YawMode(False, 0))
    time.sleep(0.5)
