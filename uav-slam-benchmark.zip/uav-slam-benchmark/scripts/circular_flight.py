import airsim
import time
import math

# Connect to AirSim
client = airsim.MultirotorClient()
client.confirmConnection()
client.enableApiControl(True)
client.armDisarm(True)

# Take off
print("Taking off...")
client.takeoffAsync().join()

# Parameters for circular path
radius = 5       # m
speed = 1        # m/s
duration = 10    # s
steps = 100      # number of segments to approximate the circle
angle_step = 2 * math.pi / steps
dt = duration / steps

print("Flying in a circle>>>>>")
for i in range(steps):
    angle = i * angle_step
    x = radius * math.cos(angle)
    y = radius * math.sin(angle)
    yaw = math.degrees(angle)  # optional yaw adjustment
    client.moveToPositionAsync(x, y, -2, speed, yaw_mode=airsim.YawMode(is_rate=False, yaw_or_rate=yaw)).join()
    time.sleep(dt)

# Hover
print("Hovering>>>>")
client.hoverAsync().join()
time.sleep(1)

# Land
print("Landing>>>>")
client.landAsync().join()

client.armDisarm(False)
client.enableApiControl(False)
print("flight completed.")
