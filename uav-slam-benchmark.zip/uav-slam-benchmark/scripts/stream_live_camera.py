import airsim
import numpy as np
import cv2
import time

# Connect to the AirSim simulator
client = airsim.MultirotorClient()
client.confirmConnection()

# Setup: which camera and image type to request
camera_name = "0"
image_type = airsim.ImageType.Scene

print("Press>>>> 'q' to quit.")

while True:
    # Get i
    response = client.simGetImage(camera_name, image_type)

    if response:
        # Convert 
        img_array = np.frombuffer(response, dtype=np.uint8)
        # Decode 
        frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)

        cv2.imshow("Live Drone Camera", frame)

        # Exit on 'q'
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q') or cv2.getWindowProperty('Live Drone Camera', cv2.WND_PROP_VISIBLE) < 1:
            break
    else:
        print("No image received<<<")
        time.sleep(0.1)

cv2.destroyAllWindows()
