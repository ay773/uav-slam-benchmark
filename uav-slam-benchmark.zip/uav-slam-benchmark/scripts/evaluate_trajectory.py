import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import sys
import os




if len(sys.argv) < 2:
    print("Usage: python evaluate_trajectory.py <trajectory_csv_file>")
    sys.exit(1)



file_path = sys.argv[1]

if not os.path.exists(file_path):
    print(f"File not found: {file_path}")
    sys.exit(1)

# Load trajectory
df = pd.read_csv(file_path)
x = df['x'].values
y = df['y'].values
z = df['z'].values

# Compute metrics
def compute_total_distance(x, y, z):
    deltas = np.sqrt(np.diff(x)**2 + np.diff(y)**2 + np.diff(z)**2)
    return np.sum(deltas)




total_distance = compute_total_distance(x, y, z)
max_x, min_x = np.max(x), np.min(x)
max_y, min_y = np.max(y), np.min(y)
max_z, min_z = np.max(z), np.min(z)

# Print metrics
print(" Trajectory Evaluation Metrics:")
print(f" Total Flight Distance: {total_distance:.2f} units")
print(f" X Range: {min_x:.2f} to {max_x:.2f}")
print(f" Y Range: {min_y:.2f} to {max_y:.2f}")
print(f" Z Range: {min_z:.2f} to {max_z:.2f}")

# Plot x, y, z over time
plt.figure(figsize=(12, 8))

plt.subplot(3, 1, 1)
plt.plot(x, label='X', color='r')
plt.ylabel('X Position')
plt.grid(True)

plt.subplot(3, 1, 2)
plt.plot(y, label='Y', color='g')
plt.ylabel('Y Position')
plt.grid(True)

plt.subplot(3, 1, 3)
plt.plot(z, label='Z', color='b')
plt.ylabel('Z Position')
plt.xlabel('Frame Index')
plt.grid(True)

plt.suptitle("UAV Trajectory Components Over Time")
plt.tight_layout()
plt.show()
