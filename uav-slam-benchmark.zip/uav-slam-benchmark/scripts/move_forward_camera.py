import airsim
import numpy as np
import cv2
import time

# Connect to AirSim
client = airsim.MultirotorClient()
client.confirmConnection()
client.enableApiControl(True)
client.armDisarm(True)

# Take off
client.takeoffAsync().join()
print("Taking off>>>>")

# Move forward
duration = 4  # sec
speed = 2     # m/s
client.moveByVelocityAsync(speed, 0, 0, duration, drivetrain=airsim.DrivetrainType.ForwardOnly, yaw_mode=airsim.YawMode(False, 0))

#settings
camera_name = "0"
image_type = airsim.ImageType.Scene

#capturing frames
start_time = time.time()
while time.time() - start_time < duration:
    response = client.simGetImage(camera_name, image_type)
    if response:
        img_array = np.frombuffer(response, dtype=np.uint8)
        frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        cv2.imshow("Drone Forward Camera", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        print("No image received-tryagain")


client.landAsync().join()
client.armDisarm(False)
client.enableApiControl(False)
cv2.destroyAllWindows()
