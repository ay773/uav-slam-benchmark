import airsim
import cv2
import numpy as np
import time

# connect to airSim
client = airsim.MultirotorClient()
client.confirmConnection()
print("Connected!")

# camera settings
camera_name = "0"
image_type = airsim.ImageType.Scene


def get_frame():
    response = client.simGetImage(camera_name, image_type)
    if response:
        img_array = np.frombuffer(response, dtype=np.uint8)
        frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        return frame
    else:
        return None
    
frame1 = None
while frame1 is None:
    frame1 = get_frame()

time.sleep(0.5)  
frame2 = None
while frame2 is None:
    frame2 = get_frame()


orb = cv2.ORB_create()
kp1, des1 = orb.detectAndCompute(frame1, None)
kp2, des2 = orb.detectAndCompute(frame2, None)


bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
matches = bf.match(des1, des2)
matches = sorted(matches, key=lambda x: x.distance)


pts1 = np.float32([kp1[m.queryIdx].pt for m in matches])
pts2 = np.float32([kp2[m.trainIdx].pt for m in matches])


focal_length = 320  # pixels
center = (frame1.shape[1] / 2, frame1.shape[0] / 2)
K = np.array([[focal_length, 0, center[0]],
              [0, focal_length, center[1]],
              [0, 0, 1]])


E, mask = cv2.findEssentialMat(pts1, pts2, K, method=cv2.RANSAC, threshold=1.0)


_, R, t, mask_pose = cv2.recoverPose(E, pts1, pts2, K)


print("\nEstimated Rotation (R):\n", R)
print("\nEstimated Translation (t):\n", t)


match_img = cv2.drawMatches(frame1, kp1, frame2, kp2, matches[:20], None, flags=2)
cv2.imshow("ORB Matches", match_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
