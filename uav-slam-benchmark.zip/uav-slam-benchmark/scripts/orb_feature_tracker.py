import airsim
import numpy as np
import cv2
import time

# Connect to the AirSim 
client = airsim.MultirotorClient()
client.confirmConnection()

# Camera 
camera_name = "0"
image_type = airsim.ImageType.Scene

# Wait for the drone
time.sleep(1)

def get_drone_image():
    response = client.simGetImage(camera_name, image_type)
    if response:
        img_array = np.frombuffer(response, dtype=np.uint8)
        return cv2.imdecode(img_array, cv2.IMREAD_COLOR)
    return None

# Capture
print("Capturing frames>>>")
frame1 = get_drone_image()
time.sleep(0.2)
frame2 = get_drone_image()

# Initialise 
orb = cv2.ORB_create()


kp1, des1 = orb.detectAndCompute(frame1, None)
kp2, des2 = orb.detectAndCompute(frame2, None)
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

matches = bf.match(des1, des2)
matches = sorted(matches, key=lambda x: x.distance)
matched_img = cv2.drawMatches(frame1, kp1, frame2, kp2, matches[:30], None, flags=2)

# Show result
cv2.imshow("ORB Feature Matches", matched_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
