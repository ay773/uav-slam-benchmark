import airsim
import os
import numpy as np
import cv2
import time
from datetime import datetime

# Connect to the AirSim simulator
client = airsim.MultirotorClient()
client.confirmConnection()

# Arm and take off
client.enableApiControl(True)
client.armDisarm(True)
client.takeoffAsync().join()

# Make a unique folder for this flight
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_dir = f"images_flight_{timestamp}"
os.makedirs(output_dir, exist_ok=True)

print(f"Saving images to: {output_dir}")
i = 0

try:
    while True:
        responses = client.simGetImages([airsim.ImageRequest("0", airsim.ImageType.Scene, False, False)])
        if responses:
            img1d = np.frombuffer(responses[0].image_data_uint8, dtype=np.uint8)
            img_rgb = img1d.reshape(responses[0].height, responses[0].width, 3)
            filename = os.path.join(output_dir, f"image_{i:04d}.png")
            cv2.imwrite(filename, img_rgb)
            print(f"Saved: {filename}")
            i += 1
        time.sleep(0.25)

except KeyboardInterrupt:
    print("Image capture stopped.")

finally:
    client.landAsync().join()
    client.armDisarm(False)
    client.enableApiControl(False)
