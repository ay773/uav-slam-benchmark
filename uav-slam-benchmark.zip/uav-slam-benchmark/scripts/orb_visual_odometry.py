import airsim
import numpy as np
import cv2
import time
import matplotlib.pyplot as plt

#connection
client = airsim.MultirotorClient()
client.confirmConnection()

# settings
camera_name = "0"
image_type = airsim.ImageType.Scene

# ORB detector and matcher
orb = cv2.ORB_create(2000)
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

# Camera 
f = 320
cx = 320
cy = 240
K = np.array([[f, 0, cx],
              [0, f, cy],
              [0, 0, 1]])

# Initial pose
pose = np.eye(4)
positions = []  # Store trajectory positions

print("Starting visual odometry loop>>>>>>>> Press 'q' to stop.")

# First frame
prev_gray = None

while True:
    raw_image = client.simGetImage(camera_name, image_type)
    if raw_image is None:
        continue

    img_arr = np.frombuffer(raw_image, dtype=np.uint8)
    frame = cv2.imdecode(img_arr, cv2.IMREAD_COLOR)
    curr_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    if prev_gray is not None:
        kp1, des1 = orb.detectAndCompute(prev_gray, None)
        kp2, des2 = orb.detectAndCompute(curr_gray, None)

        if des1 is not None and des2 is not None and len(des1) >= 8 and len(des2) >= 8:
            matches = bf.match(des1, des2)
            matches = sorted(matches, key=lambda x: x.distance)

            pts1 = np.float32([kp1[m.queryIdx].pt for m in matches])
            pts2 = np.float32([kp2[m.trainIdx].pt for m in matches])

            E, mask = cv2.findEssentialMat(pts1, pts2, K, method=cv2.RANSAC, threshold=1.0)
            if E is not None:
                _, R, t, _ = cv2.recoverPose(E, pts1, pts2, K)

                # Build transformation matrix
                T = np.eye(4)
                T[:3, :3] = R
                T[:3, 3] = t.flatten()

                # Update
                pose = pose @ np.linalg.inv(T)

                # Store
                x, z = pose[0, 3], pose[2, 3]
                positions.append((x, z))

            
            match_vis = cv2.drawMatches(prev_gray, kp1, curr_gray, kp2, matches[:30], None, flags=2)
            cv2.imshow("ORB Feature Matches", match_vis)

    prev_gray = curr_gray.copy()

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()

# Convert 
positions = np.array(positions)

# Plotting 
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot(positions[:, 0], np.zeros_like(positions[:, 0]), positions[:, 1], marker='o')

ax.set_title("UAV Flight Path (Visual Odometry)")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
plt.show()
