import airsim
import cv2
import numpy as np
import time
import os
import datetime
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Connect to the AirSim simulator
client = airsim.MultirotorClient()
client.confirmConnection()

print("Starting visual odometry loop...")

# Intrinsic camera parameters (from AirSim or your calibration)
fx = 320
fy = 320
cx = 256
cy = 144
K = np.array([[fx, 0, cx],
              [0, fy, cy],
              [0,  0,  1]])

# Initialize ORB detector
orb = cv2.ORB_create()
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

# Get first image
responses = client.simGetImages([airsim.ImageRequest("0", airsim.ImageType.Scene, False, False)])
img1d = np.frombuffer(responses[0].image_data_uint8, dtype=np.uint8)
img_rgb = img1d.reshape(responses[0].height, responses[0].width, 3)
prev_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
kp1, des1 = orb.detectAndCompute(prev_gray, None)

# Pose initialization
pose = np.eye(4)
positions = []

while True:
    # Get next image
    responses = client.simGetImages([airsim.ImageRequest("0", airsim.ImageType.Scene, False, False)])
    img1d = np.frombuffer(responses[0].image_data_uint8, dtype=np.uint8)
    img_rgb = img1d.reshape(responses[0].height, responses[0].width, 3)
    curr_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

    # ORB feature detection and matching
    kp2, des2 = orb.detectAndCompute(curr_gray, None)
    if des1 is None or des2 is None:
        continue
    matches = bf.match(des1, des2)
    matches = sorted(matches, key=lambda x: x.distance)

    # Get matched points
    pts1 = np.float32([kp1[m.queryIdx].pt for m in matches])
    pts2 = np.float32([kp2[m.trainIdx].pt for m in matches])

    # Compute Essential matrix
    E, mask = cv2.findEssentialMat(pts1, pts2, K, method=cv2.RANSAC, threshold=1.0)
    if E is not None:
        try:
            _, R, t, _ = cv2.recoverPose(E, pts1, pts2, K)

            # Compose pose
            T = np.eye(4)
            T[:3, :3] = R
            T[:3, 3] = t.flatten()

            # Update global pose
            pose = pose @ np.linalg.inv(T)

            # Save position
            x, y, z = pose[0, 3], pose[1, 3], pose[2, 3]
            positions.append((x, y, z))
        except cv2.error:
            continue

    # Show matches
    match_vis = cv2.drawMatches(prev_gray, kp1, curr_gray, kp2, matches[:30], None, flags=2)
    cv2.imshow("ORB Feature Matches", match_vis)

    key = cv2.waitKey(1)
    if key == ord('q'):
        break

    prev_gray = curr_gray.copy()
    kp1, des1 = kp2, des2

cv2.destroyAllWindows()

# Save trajectory 
timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
filename = f"trajectory_{timestamp}.csv"

with open(filename, mode='w', newline='') as f:
    f.write("x,y,z\n")
    for x, y, z in positions:
        f.write(f"{x},{y},{z}\n")

print(f"Trajtory saved to {filename}")

# Plot 3D trajectory
positions = np.array(positions)
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot(positions[:, 0], positions[:, 1], positions[:, 2], marker='o')
ax.set_title("UAV Flight Path (Visual Odometry)")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
plt.show()
