import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys

filename = sys.argv[1] if len(sys.argv) > 1 else "trajectory.csv"

# Load the CSV
df = pd.read_csv(filename)

# Extract x, y, z
x = df['x']
y = df['y']
z = df['z']

# Plot 3D Trajectory
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot(x, y, z, marker='o')
ax.set_title("UAV Flight Path (Visual Odometry)")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
plt.show()
