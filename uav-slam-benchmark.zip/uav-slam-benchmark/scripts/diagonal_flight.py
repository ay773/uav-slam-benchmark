import airsim
import time
import os
import datetime

# Connect to the airSim simulator
client = airsim.MultirotorClient()
client.confirmConnection()
client.enableApiControl(True)
client.armDisarm(True)

print("Taking off...")
client.takeoffAsync().join()
time.sleep(1)

print("Flying diagonally (forward + right)>>>>")
duration = 5  # sec
vx = 1        # x
vy = 1        # y
vz = 0        # z
client.moveByVelocityZAsync(vx, vy, -2, duration, drivetrain=airsim.DrivetrainType.MaxDegreeOfFreedom, yaw_mode=airsim.YawMode(False, 0)).join()

print("Hovering>>>>>")
client.hoverAsync().join()
time.sleep(1)

print("Landing>>>>")
client.landAsync().join()
client.armDisarm(False)
client.enableApiControl(False)
print("Diagonal flight completed>>>>")
